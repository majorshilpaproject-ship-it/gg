import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  department: text("department"),
});

export const courses = pgTable("courses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  outcomes: jsonb("outcomes").notNull(),
  coPoMapping: jsonb("co_po_mapping"),
  createdAt: text("created_at").default(sql`now()`),
});

export const materials = pgTable("materials", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  courseId: varchar("course_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull(),
  uploadedAt: text("uploaded_at").default(sql`now()`),
});

export const questionBank = pgTable("question_bank", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  courseId: varchar("course_id").notNull(),
  outcomeId: text("outcome_id").notNull(),
  question: text("question").notNull(),
  marks: integer("marks").notNull(),
  difficulty: text("difficulty").notNull(),
  type: text("type").notNull(),
  createdAt: text("created_at").default(sql`now()`),
});

export const questionPapers = pgTable("question_papers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  courseId: varchar("course_id"),
  collegeName: text("college_name").notNull(),
  subjectName: text("subject_name").notNull(),
  subjectCode: text("subject_code"),
  level: text("level").notNull(),
  semester: text("semester").notNull(),
  academicYear: text("academic_year"),
  totalMarks: integer("total_marks").notNull(),
  duration: text("duration").notNull(),
  sections: jsonb("sections").notNull(),
  syllabus: text("syllabus"),
  questions: jsonb("questions"),
  createdAt: text("created_at").default(sql`now()`),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  department: true,
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
  createdAt: true,
});

export const insertMaterialSchema = createInsertSchema(materials).omit({
  id: true,
  uploadedAt: true,
});

export const insertQuestionBankSchema = createInsertSchema(questionBank).omit({
  id: true,
  createdAt: true,
});

export const insertQuestionPaperSchema = createInsertSchema(questionPapers).omit({
  id: true,
  createdAt: true,
});

export const courseOutcomeSchema = z.object({
  id: z.string(),
  description: z.string(),
});

export const coPoMappingSchema = z.object({
  outcomeId: z.string(),
  poMappings: z.record(z.string(), z.number()),
});

export const sectionConfigSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.enum(["short", "long", "problem"]),
  questionCount: z.number().min(1),
  marksEach: z.number().min(1),
  instruction: z.enum(["all", "any"]),
  anyCount: z.number().optional(),
  difficultyDistribution: z.object({
    easy: z.number().min(0).max(100),
    medium: z.number().min(0).max(100),
    hard: z.number().min(0).max(100),
  }),
});

export const generatedQuestionSchema = z.object({
  id: z.string(),
  sectionId: z.string(),
  questionNumber: z.number(),
  content: z.string(),
  marks: z.number(),
  difficulty: z.enum(["easy", "medium", "hard"]),
  type: z.enum(["short", "long", "problem"]),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;
export type InsertMaterial = z.infer<typeof insertMaterialSchema>;
export type Material = typeof materials.$inferSelect;
export type InsertQuestionBank = z.infer<typeof insertQuestionBankSchema>;
export type QuestionBankItem = typeof questionBank.$inferSelect;
export type InsertQuestionPaper = z.infer<typeof insertQuestionPaperSchema>;
export type QuestionPaper = typeof questionPapers.$inferSelect;
export type CourseOutcome = z.infer<typeof courseOutcomeSchema>;
export type CoPoMapping = z.infer<typeof coPoMappingSchema>;
export type SectionConfig = z.infer<typeof sectionConfigSchema>;
export type GeneratedQuestion = z.infer<typeof generatedQuestionSchema>;
