import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertQuestionPaperSchema, sectionConfigSchema, insertCourseSchema, insertMaterialSchema, insertQuestionBankSchema } from "@shared/schema";
import { generateQuestions } from "./services/gemini";
import { z } from "zod";

const generateQuestionsSchema = z.object({
  subjectName: z.string().min(1),
  subjectCode: z.string().optional(),
  level: z.string().min(1),
  semester: z.string().min(1),
  sections: z.array(sectionConfigSchema),
  syllabus: z.string().optional(),
  coverEntireSyllabus: z.boolean().default(true),
  avoidRepetition: z.boolean().default(true),
  balanceQuestionTypes: z.boolean().default(true),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Course routes
  app.get('/api/courses', async (req, res) => {
    try {
      const courses = await storage.getAllCourses();
      res.json(courses);
    } catch (error) {
      console.error('Get courses error:', error);
      res.status(500).json({ error: 'Failed to retrieve courses' });
    }
  });

  app.get('/api/courses/:id', async (req, res) => {
    try {
      const course = await storage.getCourse(req.params.id);
      if (!course) {
        return res.status(404).json({ error: 'Course not found' });
      }
      res.json(course);
    } catch (error) {
      console.error('Get course error:', error);
      res.status(500).json({ error: 'Failed to retrieve course' });
    }
  });

  app.post('/api/courses', async (req, res) => {
    try {
      const validated = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(validated);
      res.json(course);
    } catch (error) {
      console.error('Create course error:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Failed to create course' 
      });
    }
  });

  app.patch('/api/courses/:id', async (req, res) => {
    try {
      const course = await storage.updateCourse(req.params.id, req.body);
      if (!course) {
        return res.status(404).json({ error: 'Course not found' });
      }
      res.json(course);
    } catch (error) {
      console.error('Update course error:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Failed to update course' 
      });
    }
  });

  app.delete('/api/courses/:id', async (req, res) => {
    try {
      const deleted = await storage.deleteCourse(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: 'Course not found' });
      }
      res.json({ message: 'Course deleted successfully' });
    } catch (error) {
      console.error('Delete course error:', error);
      res.status(500).json({ error: 'Failed to delete course' });
    }
  });

  // Material routes
  app.get('/api/materials/course/:courseId', async (req, res) => {
    try {
      const materials = await storage.getMaterialsByCourse(req.params.courseId);
      res.json(materials);
    } catch (error) {
      console.error('Get materials error:', error);
      res.status(500).json({ error: 'Failed to retrieve materials' });
    }
  });

  app.post('/api/materials', async (req, res) => {
    try {
      const validated = insertMaterialSchema.parse(req.body);
      const material = await storage.createMaterial(validated);
      res.json(material);
    } catch (error) {
      console.error('Create material error:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Failed to create material' 
      });
    }
  });

  app.delete('/api/materials/:id', async (req, res) => {
    try {
      const deleted = await storage.deleteMaterial(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: 'Material not found' });
      }
      res.json({ message: 'Material deleted successfully' });
    } catch (error) {
      console.error('Delete material error:', error);
      res.status(500).json({ error: 'Failed to delete material' });
    }
  });

  // Question Bank routes
  app.get('/api/question-bank/course/:courseId', async (req, res) => {
    try {
      const questions = await storage.getQuestionsByCourse(req.params.courseId);
      res.json(questions);
    } catch (error) {
      console.error('Get question bank error:', error);
      res.status(500).json({ error: 'Failed to retrieve questions' });
    }
  });

  app.post('/api/question-bank', async (req, res) => {
    try {
      const validated = insertQuestionBankSchema.parse(req.body);
      const question = await storage.createQuestionBankItem(validated);
      res.json(question);
    } catch (error) {
      console.error('Create question bank item error:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Failed to create question' 
      });
    }
  });

  app.delete('/api/question-bank/:id', async (req, res) => {
    try {
      const deleted = await storage.deleteQuestionBankItem(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: 'Question not found' });
      }
      res.json({ message: 'Question deleted successfully' });
    } catch (error) {
      console.error('Delete question error:', error);
      res.status(500).json({ error: 'Failed to delete question' });
    }
  });

  // Generate questions using AI
  app.post('/api/generate-questions', async (req, res) => {
    try {
      const validated = generateQuestionsSchema.parse(req.body);
      const result = await generateQuestions(validated);
      res.json(result);
    } catch (error) {
      console.error('Generate questions error:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Failed to generate questions' 
      });
    }
  });

  // Save question paper draft
  app.post('/api/question-papers', async (req, res) => {
    try {
      const validated = insertQuestionPaperSchema.parse(req.body);
      const paper = await storage.createQuestionPaper(validated);
      res.json(paper);
    } catch (error) {
      console.error('Save question paper error:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Failed to save question paper' 
      });
    }
  });

  // Get question paper by ID
  app.get('/api/question-papers/:id', async (req, res) => {
    try {
      const paper = await storage.getQuestionPaper(req.params.id);
      if (!paper) {
        return res.status(404).json({ error: 'Question paper not found' });
      }
      res.json(paper);
    } catch (error) {
      console.error('Get question paper error:', error);
      res.status(500).json({ error: 'Failed to retrieve question paper' });
    }
  });

  // Update question paper
  app.patch('/api/question-papers/:id', async (req, res) => {
    try {
      const updates = req.body;
      const paper = await storage.updateQuestionPaper(req.params.id, updates);
      if (!paper) {
        return res.status(404).json({ error: 'Question paper not found' });
      }
      res.json(paper);
    } catch (error) {
      console.error('Update question paper error:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Failed to update question paper' 
      });
    }
  });

  // Get all question papers
  app.get('/api/question-papers', async (req, res) => {
    try {
      // For demo purposes, get all papers (in production, filter by user)
      const papers = await storage.getUserQuestionPapers('demo-user');
      res.json(papers);
    } catch (error) {
      console.error('List question papers error:', error);
      res.status(500).json({ error: 'Failed to retrieve question papers' });
    }
  });

  // Delete question paper
  app.delete('/api/question-papers/:id', async (req, res) => {
    try {
      const deleted = await storage.deleteQuestionPaper(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: 'Question paper not found' });
      }
      res.json({ message: 'Question paper deleted successfully' });
    } catch (error) {
      console.error('Delete question paper error:', error);
      res.status(500).json({ error: 'Failed to delete question paper' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
