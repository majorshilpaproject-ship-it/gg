import { type User, type InsertUser, type QuestionPaper, type InsertQuestionPaper, type Course, type InsertCourse, type Material, type InsertMaterial, type QuestionBankItem, type InsertQuestionBank } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getCourse(id: string): Promise<Course | undefined>;
  getAllCourses(): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: string, course: Partial<Course>): Promise<Course | undefined>;
  deleteCourse(id: string): Promise<boolean>;
  
  getMaterial(id: string): Promise<Material | undefined>;
  getMaterialsByCourse(courseId: string): Promise<Material[]>;
  createMaterial(material: InsertMaterial): Promise<Material>;
  deleteMaterial(id: string): Promise<boolean>;
  
  getQuestionBankItem(id: string): Promise<QuestionBankItem | undefined>;
  getQuestionsByCourse(courseId: string): Promise<QuestionBankItem[]>;
  createQuestionBankItem(question: InsertQuestionBank): Promise<QuestionBankItem>;
  deleteQuestionBankItem(id: string): Promise<boolean>;
  
  getQuestionPaper(id: string): Promise<QuestionPaper | undefined>;
  createQuestionPaper(paper: InsertQuestionPaper): Promise<QuestionPaper>;
  updateQuestionPaper(id: string, paper: Partial<QuestionPaper>): Promise<QuestionPaper | undefined>;
  deleteQuestionPaper(id: string): Promise<boolean>;
  getUserQuestionPapers(userId: string): Promise<QuestionPaper[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private courses: Map<string, Course>;
  private materials: Map<string, Material>;
  private questionBank: Map<string, QuestionBankItem>;
  private questionPapers: Map<string, QuestionPaper>;

  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.materials = new Map();
    this.questionBank = new Map();
    this.questionPapers = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, department: insertUser.department ?? null };
    this.users.set(id, user);
    return user;
  }

  async getCourse(id: string): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async getAllCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = randomUUID();
    const course: Course = {
      ...insertCourse,
      description: insertCourse.description ?? null,
      coPoMapping: insertCourse.coPoMapping ?? null,
      id,
      createdAt: new Date().toISOString(),
    };
    this.courses.set(id, course);
    return course;
  }

  async updateCourse(id: string, updates: Partial<Course>): Promise<Course | undefined> {
    const existing = this.courses.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...updates };
    this.courses.set(id, updated);
    return updated;
  }

  async deleteCourse(id: string): Promise<boolean> {
    return this.courses.delete(id);
  }

  async getMaterial(id: string): Promise<Material | undefined> {
    return this.materials.get(id);
  }

  async getMaterialsByCourse(courseId: string): Promise<Material[]> {
    return Array.from(this.materials.values()).filter(m => m.courseId === courseId);
  }

  async createMaterial(insertMaterial: InsertMaterial): Promise<Material> {
    const id = randomUUID();
    const material: Material = {
      ...insertMaterial,
      id,
      uploadedAt: new Date().toISOString(),
    };
    this.materials.set(id, material);
    return material;
  }

  async deleteMaterial(id: string): Promise<boolean> {
    return this.materials.delete(id);
  }

  async getQuestionBankItem(id: string): Promise<QuestionBankItem | undefined> {
    return this.questionBank.get(id);
  }

  async getQuestionsByCourse(courseId: string): Promise<QuestionBankItem[]> {
    return Array.from(this.questionBank.values()).filter(q => q.courseId === courseId);
  }

  async createQuestionBankItem(insertQuestion: InsertQuestionBank): Promise<QuestionBankItem> {
    const id = randomUUID();
    const question: QuestionBankItem = {
      ...insertQuestion,
      id,
      createdAt: new Date().toISOString(),
    };
    this.questionBank.set(id, question);
    return question;
  }

  async deleteQuestionBankItem(id: string): Promise<boolean> {
    return this.questionBank.delete(id);
  }

  async getQuestionPaper(id: string): Promise<QuestionPaper | undefined> {
    return this.questionPapers.get(id);
  }

  async createQuestionPaper(insertPaper: InsertQuestionPaper): Promise<QuestionPaper> {
    const id = randomUUID();
    const paper: QuestionPaper = {
      ...insertPaper,
      courseId: insertPaper.courseId ?? null,
      subjectCode: insertPaper.subjectCode ?? null,
      academicYear: insertPaper.academicYear ?? null,
      syllabus: insertPaper.syllabus ?? null,
      questions: insertPaper.questions ?? null,
      id,
      createdAt: new Date().toISOString(),
    };
    this.questionPapers.set(id, paper);
    return paper;
  }

  async updateQuestionPaper(id: string, updates: Partial<QuestionPaper>): Promise<QuestionPaper | undefined> {
    const existing = this.questionPapers.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.questionPapers.set(id, updated);
    return updated;
  }

  async deleteQuestionPaper(id: string): Promise<boolean> {
    return this.questionPapers.delete(id);
  }

  async getUserQuestionPapers(userId: string): Promise<QuestionPaper[]> {
    // For demo purposes, return all papers since we don't have user sessions
    return Array.from(this.questionPapers.values());
  }
}

export const storage = new MemStorage();
