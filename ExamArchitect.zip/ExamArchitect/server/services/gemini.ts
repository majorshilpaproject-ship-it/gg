import { GoogleGenAI } from "@google/genai";
import { type SectionConfig, type GeneratedQuestion } from "@shared/schema";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface QuestionGenerationRequest {
  subjectName: string;
  subjectCode?: string;
  level: string;
  semester: string;
  sections: SectionConfig[];
  syllabus?: string;
  coverEntireSyllabus: boolean;
  avoidRepetition: boolean;
  balanceQuestionTypes: boolean;
}

export interface QuestionGenerationResponse {
  sections: {
    sectionId: string;
    questions: GeneratedQuestion[];
  }[];
}

export async function generateQuestions(request: QuestionGenerationRequest): Promise<QuestionGenerationResponse> {
  const systemPrompt = `You are an AI assistant that generates question papers automatically. You must follow the structure and requirements strictly.

Context:
- Subject: ${request.subjectName} ${request.subjectCode ? `(${request.subjectCode})` : ''}
- Level: ${request.level}
- Semester: ${request.semester}
- Syllabus Topics: ${request.syllabus || 'Standard curriculum topics'}

Requirements:
- Generate questions according to the specified sections and difficulty distributions
- Each question must clearly mention marks allocated
- Avoid repetition of questions: ${request.avoidRepetition}
- Maintain a balance between theory, problem-solving, and application-based questions: ${request.balanceQuestionTypes}
- Ensure that the question paper covers the syllabus fairly: ${request.coverEntireSyllabus}
- Questions should be appropriate for the academic level and semester

Response must be in JSON format with the following structure:
{
  "sections": [
    {
      "sectionId": "section_id",
      "questions": [
        {
          "id": "unique_id",
          "sectionId": "section_id", 
          "questionNumber": 1,
          "content": "Question text here",
          "marks": 2,
          "difficulty": "easy|medium|hard",
          "type": "short|long|problem"
        }
      ]
    }
  ]
}`;

  const userPrompt = `Generate questions for the following sections:

${request.sections.map((section, index) => `
Section ${String.fromCharCode(65 + index)} (${section.name}):
- Section ID (use this exact ID in response): ${section.id}
- Type: ${section.type} answer questions
- Number of questions: ${section.questionCount}
- Marks per question: ${section.marksEach}
- Instruction: ${section.instruction === 'all' ? 'Answer all questions' : `Answer any ${section.anyCount || Math.ceil(section.questionCount * 0.8)} questions`}
- Difficulty distribution: ${section.difficultyDistribution.easy}% easy, ${section.difficultyDistribution.medium}% medium, ${section.difficultyDistribution.hard}% hard
`).join('\n')}

Generate unique, well-crafted questions that test different aspects of ${request.subjectName} appropriate for ${request.level} level, semester ${request.semester}.
IMPORTANT: Use the exact Section ID provided for each section in your response's sectionId field.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            sections: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  sectionId: { type: "string" },
                  questions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        id: { type: "string" },
                        sectionId: { type: "string" },
                        questionNumber: { type: "number" },
                        content: { type: "string" },
                        marks: { type: "number" },
                        difficulty: { type: "string" },
                        type: { type: "string" },
                      },
                      required: ["id", "sectionId", "questionNumber", "content", "marks", "difficulty", "type"],
                    },
                  },
                },
                required: ["sectionId", "questions"],
              },
            },
          },
          required: ["sections"],
        },
      },
      contents: userPrompt,
    });

    const rawJson = response.text;
    if (rawJson) {
      const result: QuestionGenerationResponse = JSON.parse(rawJson);
      return result;
    } else {
      throw new Error("Empty response from Gemini API");
    }
  } catch (error) {
    console.error('Gemini API Error:', error);
    throw new Error(`Failed to generate questions: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
