import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, Printer, Download, FileText } from "lucide-react";
import { type SectionConfig, type GeneratedQuestion } from "@shared/schema";

interface QuestionPaperPreviewProps {
  data: {
    collegeName: string;
    subjectName: string;
    subjectCode: string;
    level: string;
    semester: string;
    academicYear: string;
    totalMarks: number;
    duration: string;
    sections: SectionConfig[];
    syllabus: string;
    questions?: {
      sectionId: string;
      questions: GeneratedQuestion[];
    }[];
  };
  isGenerating: boolean;
}

export default function QuestionPaperPreview({ data, isGenerating }: QuestionPaperPreviewProps) {
  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = () => {
    // This would integrate with a PDF generation library like react-to-pdf or puppeteer
    // For now, we'll trigger the print dialog as a fallback
    window.print();
  };

  const hasBasicInfo = data.collegeName || data.subjectName || data.level;
  const hasQuestions = data.questions && data.questions.length > 0;

  const getInstructionText = (section: SectionConfig) => {
    if (section.instruction === "all") {
      return "Answer all questions.";
    }
    return `Answer any ${section.anyCount || Math.ceil(section.questionCount * 0.8)} questions.`;
  };

  const getSectionTitle = (section: SectionConfig, questions: GeneratedQuestion[]) => {
    const typeMap = {
      short: "Short Answer Questions",
      long: "Long Answer Questions", 
      problem: "Problem Solving Questions",
    };
    
    const totalMarks = questions.length * section.marksEach;
    const instruction = section.instruction === "any" 
      ? ` (Answer any ${section.anyCount || Math.ceil(section.questionCount * 0.8)} questions)`
      : "";
    
    return `${section.name} - ${typeMap[section.type]} (${questions.length} × ${section.marksEach} = ${totalMarks} Marks)${instruction}`;
  };

  if (!hasBasicInfo) {
    return (
      <Card>
        <CardContent className="bg-gradient-to-r from-primary to-secondary px-6 py-4 text-white">
          <h2 className="font-semibold flex items-center">
            <Eye className="mr-2" size={20} />
            Live Preview
          </h2>
        </CardContent>
        <CardContent className="p-6 bg-muted">
          <div className="paper-preview p-12 min-h-[800px] flex items-center justify-center">
            <div className="text-center">
              <FileText className="mx-auto mb-4 text-muted-foreground" size={64} />
              <h3 className="text-xl font-semibold text-foreground mb-2">No Preview Available</h3>
              <p className="text-muted-foreground max-w-md">
                Fill in the exam details and configure sections to see a live preview of your question paper.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="bg-gradient-to-r from-primary to-secondary px-6 py-4 text-white no-print">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold flex items-center">
            <Eye className="mr-2" size={20} />
            Live Preview
          </h2>
          <div className="flex items-center space-x-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={handlePrint}
              className="bg-white/20 hover:bg-white/30 text-white border-0"
              data-testid="button-print"
            >
              <Printer className="mr-1" size={14} />
              Printer
            </Button>
            <Button
              size="sm"
              variant="secondary"
              onClick={handleDownloadPDF}
              className="bg-white/20 hover:bg-white/30 text-white border-0"
              data-testid="button-download-pdf"
            >
              <Download className="mr-1" size={14} />
              PDF
            </Button>
          </div>
        </div>
      </CardContent>
      
      <CardContent className="p-6 bg-muted max-h-[calc(100vh-200px)] overflow-y-auto">
        {isGenerating && (
          <Card className="mb-4 no-print">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="loader"></div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground mb-1">Generating Questions...</h3>
                  <p className="text-sm text-muted-foreground">AI is creating unique questions based on your specifications</p>
                  <div className="mt-3 bg-muted rounded-full h-2 overflow-hidden">
                    <div className="bg-gradient-to-r from-primary to-secondary h-full w-2/3 transition-all duration-300"></div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Estimated time: 30-60 seconds</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Paper Preview */}
        <div className="paper-preview p-12 min-h-[800px]">
          {/* Header */}
          <div className="text-center border-b-2 border-black pb-4 mb-6">
            <h1 className="text-2xl font-bold mb-2" data-testid="text-college-name-preview">
              {data.collegeName || "UNIVERSITY OF TECHNOLOGY"}
            </h1>
            <h2 className="text-xl font-semibold mb-3">End Semester Examination</h2>
            <div className="text-sm space-y-1">
              <p>
                <strong>Subject:</strong> <span data-testid="text-subject-name-preview">{data.subjectName || "Subject Name"}</span>
                {data.subjectCode && (
                  <> (<span data-testid="text-subject-code-preview">{data.subjectCode}</span>)</>
                )}
              </p>
              <p>
                <strong>Level:</strong> <span data-testid="text-level-preview">{data.level || "UG"}</span> |{" "}
                <strong>Semester:</strong> <span data-testid="text-semester-preview">{data.semester || "III"}</span>
                {data.academicYear && (
                  <> | <strong>Year:</strong> <span data-testid="text-academic-year-preview">{data.academicYear}</span></>
                )}
              </p>
              <p>
                <strong>Duration:</strong> <span data-testid="text-duration-preview">{data.duration || "3 Hours"}</span> |{" "}
                <strong>Total Marks:</strong> <span data-testid="text-total-marks-preview">{data.totalMarks || "100"}</span>
              </p>
            </div>
          </div>
          
          {/* Instructions */}
          <div className="mb-6 p-4 bg-gray-50 border border-gray-300">
            <h3 className="font-bold mb-2">Instructions to Candidates:</h3>
            <ul className="list-disc list-inside space-y-1 text-sm">
              {data.sections.map((section, index) => (
                <li key={section.id}>
                  {getInstructionText(section).replace("Answer", `Section ${String.fromCharCode(65 + index)}: Answer`)}
                </li>
              ))}
              <li>All questions carry equal marks unless specified.</li>
              <li>Write legibly and use diagrams where necessary.</li>
              <li>Mobile phones and electronic devices are not permitted.</li>
            </ul>
          </div>
          
          {/* Sections */}
          {hasQuestions ? (
            data.questions?.map((questionSet, sectionIndex) => {
              const section = data.sections.find(s => s.id === questionSet.sectionId);
              if (!section) return null;
              
              const sectionColors = [
                "border-blue-600",
                "border-purple-600", 
                "border-green-600",
                "border-orange-600",
                "border-red-600",
              ];
              
              return (
                <div key={questionSet.sectionId} className="question-section mb-8">
                  <div className={`bg-gray-100 px-4 py-2 font-bold mb-4 border-l-4 ${sectionColors[sectionIndex % sectionColors.length]}`}>
                    {getSectionTitle(section, questionSet.questions)}
                  </div>
                  <div className="space-y-3 pl-4">
                    {questionSet.questions.map((question, questionIndex) => (
                      <div key={question.id} className="flex" data-testid={`question-${question.id}`}>
                        <span className="font-semibold mr-3">{question.questionNumber}.</span>
                        <div className="flex-1">
                          <p>{question.content}</p>
                          <p className="text-sm text-gray-600 mt-1">[{question.marks} Marks]</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })
          ) : (
            // Placeholder content when no questions are generated
            data.sections.map((section, sectionIndex) => {
              const sectionColors = [
                "border-blue-600",
                "border-purple-600",
                "border-green-600", 
                "border-orange-600",
                "border-red-600",
              ];
              
              const typeMap = {
                short: "Short Answer Questions",
                long: "Long Answer Questions",
                problem: "Problem Solving Questions",
              };
              
              const totalMarks = section.questionCount * section.marksEach;
              const instruction = section.instruction === "any" 
                ? ` (Answer any ${section.anyCount || Math.ceil(section.questionCount * 0.8)} questions)`
                : "";
              
              return (
                <div key={section.id} className="question-section mb-8">
                  <div className={`bg-gray-100 px-4 py-2 font-bold mb-4 border-l-4 ${sectionColors[sectionIndex % sectionColors.length]}`}>
                    {section.name} - {typeMap[section.type]} ({section.questionCount} × {section.marksEach} = {totalMarks} Marks){instruction}
                  </div>
                  <div className="space-y-3 pl-4">
                    {Array.from({ length: Math.min(3, section.questionCount) }).map((_, questionIndex) => (
                      <div key={questionIndex} className="flex">
                        <span className="font-semibold mr-3">{questionIndex + 1}.</span>
                        <div className="flex-1">
                          <p className="text-gray-500 italic">
                            [Question will be generated here after AI processing]
                          </p>
                          <p className="text-sm text-gray-600 mt-1">[{section.marksEach} Marks]</p>
                        </div>
                      </div>
                    ))}
                    {section.questionCount > 3 && (
                      <div className="text-center text-gray-500 italic">
                        ... and {section.questionCount - 3} more questions
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
          
          {/* Footer */}
          <div className="mt-12 pt-4 border-t-2 border-black text-center text-sm">
            <p className="font-semibold">*** End of Question Paper ***</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
