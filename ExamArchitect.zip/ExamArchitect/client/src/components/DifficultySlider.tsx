import { Slider } from "@/components/ui/slider";

interface DifficultySliderProps {
  distribution: {
    easy: number;
    medium: number;
    hard: number;
  };
  onUpdate: (difficulty: "easy" | "medium" | "hard", value: number) => void;
  sectionId: string;
}

export default function DifficultySlider({ distribution, onUpdate, sectionId }: DifficultySliderProps) {
  const handleSliderChange = (difficulty: "easy" | "medium" | "hard", values: number[]) => {
    const newValue = values[0];
    const total = distribution.easy + distribution.medium + distribution.hard;
    const otherTotal = total - distribution[difficulty];
    
    // Ensure the total always adds up to 100
    if (otherTotal > 0 && newValue <= 100) {
      onUpdate(difficulty, newValue);
      
      // Adjust other values proportionally to maintain 100% total
      const remaining = 100 - newValue;
      if (remaining >= 0) {
        const otherKeys = (["easy", "medium", "hard"] as const).filter(k => k !== difficulty);
        const scale = remaining / otherTotal;
        
        otherKeys.forEach(key => {
          const adjustedValue = Math.round(distribution[key] * scale);
          onUpdate(key, Math.max(0, adjustedValue));
        });
      }
    }
  };

  const total = distribution.easy + distribution.medium + distribution.hard;
  const isValid = Math.abs(total - 100) <= 1; // Allow 1% tolerance for rounding

  return (
    <div className="mt-3">
      <label className="text-xs text-muted-foreground mb-2 block">
        Difficulty Distribution {!isValid && <span className="text-destructive">(Total: {total}%)</span>}
      </label>
      <div className="space-y-3">
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Easy</span>
            <span className="text-foreground font-medium" data-testid={`text-easy-percentage-${sectionId}`}>
              {distribution.easy}%
            </span>
          </div>
          <Slider
            value={[distribution.easy]}
            onValueChange={(values) => handleSliderChange("easy", values)}
            max={100}
            step={5}
            className="w-full"
            data-testid={`slider-easy-${sectionId}`}
          />
        </div>
        
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Medium</span>
            <span className="text-foreground font-medium" data-testid={`text-medium-percentage-${sectionId}`}>
              {distribution.medium}%
            </span>
          </div>
          <Slider
            value={[distribution.medium]}
            onValueChange={(values) => handleSliderChange("medium", values)}
            max={100}
            step={5}
            className="w-full"
            data-testid={`slider-medium-${sectionId}`}
          />
        </div>
        
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Hard</span>
            <span className="text-foreground font-medium" data-testid={`text-hard-percentage-${sectionId}`}>
              {distribution.hard}%
            </span>
          </div>
          <Slider
            value={[distribution.hard]}
            onValueChange={(values) => handleSliderChange("hard", values)}
            max={100}
            step={5}
            className="w-full"
            data-testid={`slider-hard-${sectionId}`}
          />
        </div>
      </div>
    </div>
  );
}
