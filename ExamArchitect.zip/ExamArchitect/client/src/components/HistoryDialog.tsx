import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Trash2, FileText, Calendar, BookOpen } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { type QuestionPaper } from "@shared/schema";
import { format } from "date-fns";

interface HistoryDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadPaper: (paper: QuestionPaper) => void;
}

export default function HistoryDialog({ isOpen, onClose, onLoadPaper }: HistoryDialogProps) {
  const { toast } = useToast();

  const { data: papers, isLoading } = useQuery<QuestionPaper[]>({
    queryKey: ["/api/question-papers"],
    enabled: isOpen,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/question-papers/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/question-papers"] });
      toast({
        title: "Paper Deleted",
        description: "Question paper has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Delete Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this question paper?")) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto" data-testid="dialog-history">
        <DialogHeader>
          <DialogTitle className="flex items-center text-2xl">
            <FileText className="mr-2" size={24} />
            Question Paper History
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="loader"></div>
              <span className="ml-3 text-muted-foreground">Loading history...</span>
            </div>
          ) : papers && papers.length > 0 ? (
            papers.map((paper) => (
              <Card
                key={paper.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => onLoadPaper(paper)}
                data-testid={`history-paper-${paper.id}`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-2" data-testid={`text-paper-title-${paper.id}`}>
                        {paper.title}
                      </h3>
                      <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <BookOpen size={14} className="mr-1" />
                          <span data-testid={`text-subject-${paper.id}`}>
                            {paper.subjectName}
                            {paper.subjectCode && ` (${paper.subjectCode})`}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <Calendar size={14} className="mr-1" />
                          <span data-testid={`text-created-${paper.id}`}>
                            {paper.createdAt ? format(new Date(paper.createdAt), "MMM d, yyyy") : "Unknown"}
                          </span>
                        </div>
                        <div>
                          Level: <span className="font-medium">{paper.level}</span> | Semester: <span className="font-medium">{paper.semester}</span>
                        </div>
                        <div>
                          Marks: <span className="font-medium">{paper.totalMarks}</span> | Duration: <span className="font-medium">{paper.duration}</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => handleDelete(paper.id, e)}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                      data-testid={`button-delete-${paper.id}`}
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center py-12">
              <FileText className="mx-auto mb-4 text-muted-foreground" size={48} />
              <h3 className="text-lg font-semibold mb-2">No Saved Papers</h3>
              <p className="text-muted-foreground">
                Generate and save question papers to see them here.
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
