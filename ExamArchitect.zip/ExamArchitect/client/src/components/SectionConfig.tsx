import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2 } from "lucide-react";
import { type SectionConfig } from "@shared/schema";
import DifficultySlider from "./DifficultySlider";

interface SectionConfigProps {
  section: SectionConfig;
  index: number;
  onUpdate: (sectionId: string, updates: Partial<SectionConfig>) => void;
  onRemove: (sectionId: string) => void;
}

const sectionColors = [
  "bg-primary/10 text-primary",
  "bg-secondary/10 text-secondary", 
  "bg-accent/10 text-accent",
  "bg-orange-100 text-orange-600",
  "bg-purple-100 text-purple-600",
];

const sectionTypeLabels = {
  short: "Short Answer Questions",
  long: "Long Answer Questions", 
  problem: "Problem Solving Questions",
};

export default function SectionConfig({ section, index, onUpdate, onRemove }: SectionConfigProps) {
  const handleUpdate = (field: keyof SectionConfig, value: any) => {
    onUpdate(section.id, { [field]: value });
  };

  const handleDifficultyUpdate = (difficulty: "easy" | "medium" | "hard", value: number) => {
    const newDistribution = {
      ...section.difficultyDistribution,
      [difficulty]: value,
    };
    onUpdate(section.id, { difficultyDistribution: newDistribution });
  };

  return (
    <Card className="border border-border">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${sectionColors[index % sectionColors.length]}`}>
              <span className="font-semibold text-sm">{String.fromCharCode(65 + index)}</span>
            </div>
            <div>
              <h3 className="font-medium text-foreground">{section.name}</h3>
              <p className="text-xs text-muted-foreground">
                {sectionTypeLabels[section.type]}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onRemove(section.id)}
            className="text-destructive hover:bg-destructive/10"
            data-testid={`button-remove-section-${section.id}`}
          >
            <Trash2 size={16} />
          </Button>
        </div>
        
        <div className="grid grid-cols-3 gap-3 mb-3">
          <div>
            <Input
              type="number"
              min="1"
              value={section.questionCount}
              onChange={(e) => handleUpdate("questionCount", parseInt(e.target.value) || 1)}
              placeholder="Questions"
              className="text-sm"
              data-testid={`input-question-count-${section.id}`}
            />
            <label className="text-xs text-muted-foreground">Questions</label>
          </div>
          
          <div>
            <Input
              type="number"
              min="1"
              value={section.marksEach}
              onChange={(e) => handleUpdate("marksEach", parseInt(e.target.value) || 1)}
              placeholder="Marks Each"
              className="text-sm"
              data-testid={`input-marks-each-${section.id}`}
            />
            <label className="text-xs text-muted-foreground">Marks Each</label>
          </div>
          
          <div>
            <Select 
              value={section.instruction} 
              onValueChange={(value: "all" | "any") => {
                handleUpdate("instruction", value);
                if (value === "any" && !section.anyCount) {
                  handleUpdate("anyCount", Math.ceil(section.questionCount * 0.8));
                }
              }}
            >
              <SelectTrigger className="text-sm" data-testid={`select-instruction-${section.id}`}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="any">Any X</SelectItem>
              </SelectContent>
            </Select>
            <label className="text-xs text-muted-foreground">Type</label>
          </div>
        </div>

        {section.instruction === "any" && (
          <div className="mb-3">
            <Input
              type="number"
              min="1"
              max={section.questionCount}
              value={section.anyCount || Math.ceil(section.questionCount * 0.8)}
              onChange={(e) => handleUpdate("anyCount", parseInt(e.target.value) || 1)}
              placeholder="Number to attempt"
              className="text-sm"
              data-testid={`input-any-count-${section.id}`}
            />
            <label className="text-xs text-muted-foreground">Number to attempt</label>
          </div>
        )}
        
        <DifficultySlider
          distribution={section.difficultyDistribution}
          onUpdate={handleDifficultyUpdate}
          sectionId={section.id}
        />
      </CardContent>
    </Card>
  );
}
