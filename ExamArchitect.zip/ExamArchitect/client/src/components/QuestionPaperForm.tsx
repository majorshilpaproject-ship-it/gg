import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Info, Layers, Brain, Save, Wand2, Plus } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import SectionConfig from "./SectionConfig";
import { type SectionConfig as SectionConfigType, type GeneratedQuestion } from "@shared/schema";

interface QuestionPaperFormProps {
  data: {
    collegeName: string;
    subjectName: string;
    subjectCode: string;
    level: string;
    semester: string;
    academicYear: string;
    totalMarks: number;
    duration: string;
    sections: SectionConfigType[];
    syllabus: string;
    questions?: {
      sectionId: string;
      questions: GeneratedQuestion[];
    }[];
  };
  onDataUpdate: (data: any) => void;
  onGenerationStart: () => void;
  onGenerationComplete: (questions: { sectionId: string; questions: GeneratedQuestion[]; }[]) => void;
  onGenerationError: () => void;
  isGenerating: boolean;
}

const defaultSections: SectionConfigType[] = [
  {
    id: "section-a",
    name: "Section A",
    type: "short",
    questionCount: 10,
    marksEach: 2,
    instruction: "all",
    difficultyDistribution: { easy: 40, medium: 40, hard: 20 }
  },
  {
    id: "section-b",
    name: "Section B", 
    type: "long",
    questionCount: 6,
    marksEach: 10,
    instruction: "any",
    anyCount: 4,
    difficultyDistribution: { easy: 30, medium: 50, hard: 20 }
  },
  {
    id: "section-c",
    name: "Section C",
    type: "problem",
    questionCount: 3,
    marksEach: 20,
    instruction: "any",
    anyCount: 2,
    difficultyDistribution: { easy: 20, medium: 40, hard: 40 }
  }
];

export default function QuestionPaperForm({ data, onDataUpdate, onGenerationStart, onGenerationComplete, onGenerationError, isGenerating }: QuestionPaperFormProps) {
  const [coverEntireSyllabus, setCoverEntireSyllabus] = useState(true);
  const [avoidRepetition, setAvoidRepetition] = useState(true);
  const [balanceQuestionTypes, setBalanceQuestionTypes] = useState(true);
  
  const { toast } = useToast();

  useEffect(() => {
    if (data.sections.length === 0) {
      onDataUpdate({ sections: defaultSections });
    }
  }, []);

  const generateQuestionsMutation = useMutation({
    mutationFn: async (request: any) => {
      const response = await apiRequest("POST", "/api/generate-questions", request);
      return response.json();
    },
    onSuccess: (result) => {
      onGenerationComplete(result.sections);
      toast({
        title: "Questions Generated Successfully",
        description: "Your question paper has been generated with AI assistance.",
      });
    },
    onError: (error: Error) => {
      onGenerationError();
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const saveDraftMutation = useMutation({
    mutationFn: async (paperData: any) => {
      const response = await apiRequest("POST", "/api/question-papers", paperData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Draft Saved",
        description: "Your question paper draft has been saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (field: string, value: any) => {
    onDataUpdate({ [field]: value });
  };

  const handleSectionUpdate = (sectionId: string, updates: Partial<SectionConfigType>) => {
    const updatedSections = data.sections.map(section =>
      section.id === sectionId ? { ...section, ...updates } : section
    );
    onDataUpdate({ sections: updatedSections });
  };

  const handleSectionRemove = (sectionId: string) => {
    const filteredSections = data.sections.filter(section => section.id !== sectionId);
    onDataUpdate({ sections: filteredSections });
  };

  const handleAddSection = () => {
    const newSection: SectionConfigType = {
      id: `section-${Date.now()}`,
      name: `Section ${String.fromCharCode(65 + data.sections.length)}`,
      type: "short",
      questionCount: 5,
      marksEach: 2,
      instruction: "all",
      difficultyDistribution: { easy: 50, medium: 30, hard: 20 }
    };
    onDataUpdate({ sections: [...data.sections, newSection] });
  };

  const handleGenerate = () => {
    if (!data.subjectName || !data.level || !data.semester || data.sections.length === 0) {
      toast({
        title: "Incomplete Information",
        description: "Please fill in all required fields and configure at least one section.",
        variant: "destructive",
      });
      return;
    }

    onGenerationStart();
    generateQuestionsMutation.mutate({
      subjectName: data.subjectName,
      subjectCode: data.subjectCode,
      level: data.level,
      semester: data.semester,
      sections: data.sections,
      syllabus: data.syllabus,
      coverEntireSyllabus,
      avoidRepetition,
      balanceQuestionTypes,
    });
  };

  const handleSaveDraft = () => {
    if (!data.subjectName) {
      toast({
        title: "Missing Subject Name",
        description: "Please enter a subject name to save the draft.",
        variant: "destructive",
      });
      return;
    }

    saveDraftMutation.mutate({
      title: `${data.subjectName} - ${data.level} Sem ${data.semester}`,
      collegeName: data.collegeName,
      subjectName: data.subjectName,
      subjectCode: data.subjectCode,
      level: data.level,
      semester: data.semester,
      academicYear: data.academicYear,
      totalMarks: data.totalMarks,
      duration: data.duration,
      sections: data.sections,
      syllabus: data.syllabus,
      questions: data.questions,
    });
  };

  const totalQuestions = data.sections.reduce((sum, section) => sum + section.questionCount, 0);
  const totalMarks = data.sections.reduce((sum, section) => sum + (section.questionCount * section.marksEach), 0);

  return (
    <div className="space-y-6">
      {/* Basic Information Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-foreground flex items-center">
              <Info className="text-primary mr-2" size={20} />
              Basic Information
            </h2>
            <Badge variant="secondary">Step 1 of 3</Badge>
          </div>
          
          <div className="space-y-5">
            <div className="floating-label">
              <Input
                id="collegeName"
                placeholder=" "
                value={data.collegeName}
                onChange={(e) => handleInputChange("collegeName", e.target.value)}
                className="peer"
                data-testid="input-college-name"
              />
              <label htmlFor="collegeName" className="absolute left-4 top-3 text-muted-foreground transition-all pointer-events-none peer-focus:transform peer-focus:scale-85 peer-focus:-translate-y-6 peer-focus:text-primary peer-[&:not(:placeholder-shown)]:transform peer-[&:not(:placeholder-shown)]:scale-85 peer-[&:not(:placeholder-shown)]:-translate-y-6">
                College Name *
              </label>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="floating-label">
                <Input
                  id="subjectName"
                  placeholder=" "
                  value={data.subjectName}
                  onChange={(e) => handleInputChange("subjectName", e.target.value)}
                  className="peer"
                  data-testid="input-subject-name"
                />
                <label htmlFor="subjectName" className="absolute left-4 top-3 text-muted-foreground transition-all pointer-events-none peer-focus:transform peer-focus:scale-85 peer-focus:-translate-y-6 peer-focus:text-primary peer-[&:not(:placeholder-shown)]:transform peer-[&:not(:placeholder-shown)]:scale-85 peer-[&:not(:placeholder-shown)]:-translate-y-6">
                  Subject Name *
                </label>
              </div>
              
              <div className="floating-label">
                <Input
                  id="subjectCode"
                  placeholder=" "
                  value={data.subjectCode}
                  onChange={(e) => handleInputChange("subjectCode", e.target.value)}
                  className="peer"
                  data-testid="input-subject-code"
                />
                <label htmlFor="subjectCode" className="absolute left-4 top-3 text-muted-foreground transition-all pointer-events-none peer-focus:transform peer-focus:scale-85 peer-focus:-translate-y-6 peer-focus:text-primary peer-[&:not(:placeholder-shown)]:transform peer-[&:not(:placeholder-shown)]:scale-85 peer-[&:not(:placeholder-shown)]:-translate-y-6">
                  Subject Code
                </label>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <Select value={data.level} onValueChange={(value) => handleInputChange("level", value)}>
                <SelectTrigger data-testid="select-level">
                  <SelectValue placeholder="Level *" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="UG">UG</SelectItem>
                  <SelectItem value="PG">PG</SelectItem>
                  <SelectItem value="Diploma">Diploma</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={data.semester} onValueChange={(value) => handleInputChange("semester", value)}>
                <SelectTrigger data-testid="select-semester">
                  <SelectValue placeholder="Semester *" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Semester 1</SelectItem>
                  <SelectItem value="2">Semester 2</SelectItem>
                  <SelectItem value="3">Semester 3</SelectItem>
                  <SelectItem value="4">Semester 4</SelectItem>
                  <SelectItem value="5">Semester 5</SelectItem>
                  <SelectItem value="6">Semester 6</SelectItem>
                  <SelectItem value="7">Semester 7</SelectItem>
                  <SelectItem value="8">Semester 8</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="floating-label">
                <Input
                  id="academicYear"
                  placeholder=" "
                  value={data.academicYear}
                  onChange={(e) => handleInputChange("academicYear", e.target.value)}
                  className="peer"
                  data-testid="input-academic-year"
                />
                <label htmlFor="academicYear" className="absolute left-4 top-3 text-muted-foreground transition-all pointer-events-none peer-focus:transform peer-focus:scale-85 peer-focus:-translate-y-6 peer-focus:text-primary peer-[&:not(:placeholder-shown)]:transform peer-[&:not(:placeholder-shown)]:scale-85 peer-[&:not(:placeholder-shown)]:-translate-y-6">
                  Year
                </label>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="floating-label">
                <Input
                  id="totalMarks"
                  type="number"
                  placeholder=" "
                  value={data.totalMarks || ""}
                  onChange={(e) => handleInputChange("totalMarks", parseInt(e.target.value) || 0)}
                  className="peer"
                  data-testid="input-total-marks"
                />
                <label htmlFor="totalMarks" className="absolute left-4 top-3 text-muted-foreground transition-all pointer-events-none peer-focus:transform peer-focus:scale-85 peer-focus:-translate-y-6 peer-focus:text-primary peer-[&:not(:placeholder-shown)]:transform peer-[&:not(:placeholder-shown)]:scale-85 peer-[&:not(:placeholder-shown)]:-translate-y-6">
                  Total Marks *
                </label>
              </div>
              
              <div className="floating-label">
                <Input
                  id="duration"
                  placeholder=" "
                  value={data.duration}
                  onChange={(e) => handleInputChange("duration", e.target.value)}
                  className="peer"
                  data-testid="input-duration"
                />
                <label htmlFor="duration" className="absolute left-4 top-3 text-muted-foreground transition-all pointer-events-none peer-focus:transform peer-focus:scale-85 peer-focus:-translate-y-6 peer-focus:text-primary peer-[&:not(:placeholder-shown)]:transform peer-[&:not(:placeholder-shown)]:scale-85 peer-[&:not(:placeholder-shown)]:-translate-y-6">
                  Duration (e.g., 3 Hours) *
                </label>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Section Configuration Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-foreground flex items-center">
              <Layers className="text-secondary mr-2" size={20} />
              Section Configuration
            </h2>
            <Badge variant="secondary">Step 2 of 3</Badge>
          </div>
          
          <div className="space-y-4">
            {data.sections.map((section, index) => (
              <SectionConfig
                key={section.id}
                section={section}
                index={index}
                onUpdate={handleSectionUpdate}
                onRemove={handleSectionRemove}
                data-testid={`section-config-${section.id}`}
              />
            ))}
            
            <Button
              variant="outline"
              onClick={handleAddSection}
              className="w-full py-3 border-2 border-dashed"
              data-testid="button-add-section"
            >
              <Plus className="mr-2" size={16} />
              Add Another Section
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* AI Configuration Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-foreground flex items-center">
              <Brain className="text-accent mr-2" size={20} />
              AI Generation Settings
            </h2>
            <Badge variant="secondary">Step 3 of 3</Badge>
          </div>
          
          <div className="space-y-5">
            <div className="floating-label">
              <Textarea
                id="syllabus"
                rows={4}
                placeholder=" "
                value={data.syllabus}
                onChange={(e) => handleInputChange("syllabus", e.target.value)}
                className="peer resize-none"
                data-testid="textarea-syllabus"
              />
              <label htmlFor="syllabus" className="absolute left-4 top-3 text-muted-foreground transition-all pointer-events-none peer-focus:transform peer-focus:scale-85 peer-focus:-translate-y-6 peer-focus:text-primary peer-[&:not(:placeholder-shown)]:transform peer-[&:not(:placeholder-shown)]:scale-85 peer-[&:not(:placeholder-shown)]:-translate-y-6">
                Syllabus Topics (comma-separated)
              </label>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="coverSyllabus" 
                  checked={coverEntireSyllabus} 
                  onCheckedChange={(checked) => setCoverEntireSyllabus(checked === true)}
                  data-testid="checkbox-cover-syllabus"
                />
                <div>
                  <label htmlFor="coverSyllabus" className="text-sm font-medium text-foreground cursor-pointer">
                    Cover entire syllabus
                  </label>
                  <p className="text-xs text-muted-foreground">Ensure questions span all topics</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="avoidRepetition" 
                  checked={avoidRepetition} 
                  onCheckedChange={(checked) => setAvoidRepetition(checked === true)}
                  data-testid="checkbox-avoid-repetition"
                />
                <div>
                  <label htmlFor="avoidRepetition" className="text-sm font-medium text-foreground cursor-pointer">
                    Avoid repetition
                  </label>
                  <p className="text-xs text-muted-foreground">Generate unique questions</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="balanceTypes" 
                  checked={balanceQuestionTypes} 
                  onCheckedChange={(checked) => setBalanceQuestionTypes(checked === true)}
                  data-testid="checkbox-balance-types"
                />
                <div>
                  <label htmlFor="balanceTypes" className="text-sm font-medium text-foreground cursor-pointer">
                    Balance question types
                  </label>
                  <p className="text-xs text-muted-foreground">Mix theory, problem-solving, and application</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex items-center space-x-4">
        <Button
          onClick={handleGenerate}
          disabled={isGenerating}
          className="flex-1 py-3 bg-gradient-to-r from-primary to-secondary text-white font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
          data-testid="button-generate"
        >
          {isGenerating ? (
            <div className="loader mr-2"></div>
          ) : (
            <Wand2 className="mr-2" size={16} />
          )}
          {isGenerating ? "Generating..." : "Generate Question Paper"}
        </Button>
        <Button
          variant="outline"
          onClick={handleSaveDraft}
          disabled={saveDraftMutation.isPending}
          className="px-6 py-3"
          data-testid="button-save-draft"
        >
          <Save className="mr-2" size={16} />
          Save Draft
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary" data-testid="text-total-questions">{totalQuestions}</div>
            <div className="text-xs text-muted-foreground mt-1">Total Questions</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-secondary" data-testid="text-calculated-marks">{totalMarks}</div>
            <div className="text-xs text-muted-foreground mt-1">Calculated Marks</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-accent" data-testid="text-sections-count">{data.sections.length}</div>
            <div className="text-xs text-muted-foreground mt-1">Sections</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
