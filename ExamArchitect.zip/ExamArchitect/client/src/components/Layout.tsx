import { Link, useLocation } from "wouter";
import { LayoutDashboard, BookOpen, Upload, Target, Wand2, Database, User, LogOut } from "lucide-react";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", path: "/", testId: "nav-dashboard" },
    { icon: BookOpen, label: "Materials", path: "/materials", testId: "nav-materials" },
    { icon: Upload, label: "Upload Material", path: "/upload", testId: "nav-upload" },
    { icon: Target, label: "Course Outcomes", path: "/outcomes", testId: "nav-outcomes" },
    { icon: Wand2, label: "Generate Questions", path: "/generate", testId: "nav-generate" },
    { icon: Database, label: "Question Bank", path: "/question-bank", testId: "nav-question-bank" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Header */}
      <header className="bg-blue-600 text-white shadow-md">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
              <span className="text-blue-600 font-bold text-lg">QP</span>
            </div>
            <h1 className="text-xl font-bold" data-testid="app-title">Question Paper Generator</h1>
          </div>
          <button className="flex items-center space-x-2 hover:bg-blue-700 px-3 py-2 rounded" data-testid="button-logout">
            <User size={20} />
          </button>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 min-h-[calc(100vh-72px)]">
          <div className="p-4">
            <div className="mb-6 p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                  SP
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900" data-testid="text-user-name">Welcome, Siri P</h3>
                  <p className="text-sm text-gray-600" data-testid="text-department">Department: Computer Science</p>
                </div>
              </div>
            </div>

            <nav className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.path || (item.path !== "/" && location.startsWith(item.path));
                
                return (
                  <Link key={item.path} href={item.path}>
                    <div
                      className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors cursor-pointer ${
                        isActive
                          ? "bg-blue-600 text-white"
                          : "text-gray-700 hover:bg-gray-100"
                      }`}
                      data-testid={item.testId}
                    >
                      <Icon size={20} />
                      <span className="font-medium">{item.label}</span>
                    </div>
                  </Link>
                );
              })}
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
