import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { type Course, type CourseOutcome } from "@shared/schema";
import { Wand2, Plus } from "lucide-react";

export default function GenerateQuestions() {
  const { toast } = useToast();
  const [courseId, setCourseId] = useState("");
  const [selectedOutcomes, setSelectedOutcomes] = useState<string[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const generateMutation = useMutation({
    mutationFn: async ({ course, outcomes }: { course: Course; outcomes: string[] }) => {
      const response = await apiRequest("POST", "/api/generate-questions", {
        subjectName: course.name,
        subjectCode: course.name,
        level: "UG",
        semester: "III",
        sections: [{
          id: "section-1",
          name: "Section A",
          type: "short",
          questionCount: 5,
          marksEach: 2,
          instruction: "all",
          difficultyDistribution: { easy: 40, medium: 40, hard: 20 }
        }],
        syllabus: `Generate questions for outcomes: ${outcomes.join(', ')}`,
        coverEntireSyllabus: true,
        avoidRepetition: true,
        balanceQuestionTypes: true,
      });
      return response.json();
    },
    onSuccess: async (result, variables) => {
      const questions = result.sections[0]?.questions || [];
      
      for (const question of questions) {
        for (const outcomeId of variables.outcomes) {
          await apiRequest("POST", "/api/question-bank", {
            courseId: variables.course.id,
            outcomeId,
            question: question.content,
            marks: question.marks,
            difficulty: question.difficulty,
            type: question.type,
          });
        }
      }
      
      queryClient.invalidateQueries({ queryKey: ["/api/question-bank/course"] });
      toast({
        title: "Questions Generated",
        description: `${questions.length} questions have been generated and added to the question bank.`,
      });
      setSelectedOutcomes([]);
    },
    onError: (error: Error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCourseChange = (id: string) => {
    setCourseId(id);
    const course = courses?.find(c => c.id === id);
    setSelectedCourse(course || null);
    setSelectedOutcomes([]);
  };

  const toggleOutcome = (outcomeId: string) => {
    setSelectedOutcomes(prev =>
      prev.includes(outcomeId)
        ? prev.filter(id => id !== outcomeId)
        : [...prev, outcomeId]
    );
  };

  const handleGenerate = () => {
    if (!courseId || selectedOutcomes.length === 0 || !selectedCourse) {
      toast({
        title: "Missing Information",
        description: "Please select a course and at least one outcome.",
        variant: "destructive",
      });
      return;
    }

    generateMutation.mutate({
      course: selectedCourse,
      outcomes: selectedOutcomes,
    });
  };

  const outcomes = (selectedCourse?.outcomes as CourseOutcome[]) || [];
  const coPoMapping = (selectedCourse?.coPoMapping as Record<string, Record<string, number>>) || {};

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900" data-testid="page-title">Question Generator</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="p-6">
              <h2 className="font-semibold mb-4">Select Course</h2>
              <Select value={courseId} onValueChange={handleCourseChange}>
                <SelectTrigger data-testid="select-course">
                  <SelectValue placeholder="Choose a course" />
                </SelectTrigger>
                <SelectContent>
                  {courses?.map((course) => (
                    <SelectItem key={course.id} value={course.id}>
                      {course.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedCourse && (
                <div className="mt-6">
                  <h3 className="font-semibold mb-3">Course Outcomes (CO)</h3>
                  <div className="space-y-2">
                    {outcomes.map((outcome) => (
                      <div key={outcome.id} className="flex items-start space-x-2">
                        <Checkbox
                          checked={selectedOutcomes.includes(outcome.id)}
                          onCheckedChange={() => toggleOutcome(outcome.id)}
                          data-testid={`checkbox-${outcome.id}`}
                        />
                        <div>
                          <span className="font-medium">{outcome.id}</span>
                          <p className="text-sm text-gray-600">{outcome.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardContent className="p-6">
              <h2 className="font-semibold mb-4">Program Specific Outcomes (PSOs)</h2>
              {selectedCourse && outcomes.length > 0 && (
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse text-sm">
                    <thead>
                      <tr>
                        <th className="border border-gray-300 p-2 bg-gray-50"></th>
                        {Array.from({ length: 12 }, (_, i) => `PO${i + 1}`).map(po => (
                          <th key={po} className="border border-gray-300 p-2 bg-gray-50">{po}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {outcomes.map(outcome => (
                        <tr key={outcome.id} className={selectedOutcomes.includes(outcome.id) ? 'bg-blue-50' : ''}>
                          <td className="border border-gray-300 p-2 font-medium">{outcome.id}</td>
                          {Array.from({ length: 12 }, (_, i) => `PO${i + 1}`).map(po => {
                            const value = coPoMapping[outcome.id]?.[po] || 0;
                            return (
                              <td key={po} className="border border-gray-300 p-2 text-center">
                                {value > 0 ? value : '-'}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="mt-6 flex justify-end">
            <Button
              onClick={handleGenerate}
              disabled={!courseId || selectedOutcomes.length === 0}
              className="bg-blue-600 hover:bg-blue-700"
              data-testid="button-generate"
            >
              <Wand2 size={16} className="mr-2" />
              Generate Questions
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
