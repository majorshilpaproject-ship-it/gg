import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { type Course, type QuestionBankItem } from "@shared/schema";
import { Database } from "lucide-react";

export default function QuestionBank() {
  const [courseId, setCourseId] = useState("");

  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: questions } = useQuery<QuestionBankItem[]>({
    queryKey: ["/api/question-bank/course", courseId],
    enabled: !!courseId,
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy": return "bg-green-100 text-green-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "hard": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900" data-testid="page-title">Question Bank</h1>

      <Card>
        <CardContent className="p-6">
          <div className="mb-6">
            <label className="block text-sm font-medium mb-2">Select Course</label>
            <Select value={courseId} onValueChange={setCourseId}>
              <SelectTrigger data-testid="select-course">
                <SelectValue placeholder="Choose a course" />
              </SelectTrigger>
              <SelectContent>
                {courses?.map((course) => (
                  <SelectItem key={course.id} value={course.id}>
                    {course.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {courseId && (
            <div className="space-y-4">
              {questions && questions.length > 0 ? (
                questions.map((question, index) => (
                  <Card key={question.id} className="border-l-4 border-l-blue-600">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge variant="outline">{question.outcomeId}</Badge>
                            <Badge className={getDifficultyColor(question.difficulty)}>
                              {question.difficulty}
                            </Badge>
                            <Badge variant="secondary">{question.marks} marks</Badge>
                          </div>
                          <p className="text-gray-900" data-testid={`question-${index}`}>
                            {question.question}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-12 text-gray-500">
                  <Database className="mx-auto mb-4" size={48} />
                  <p>No questions in the bank for this course yet.</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
