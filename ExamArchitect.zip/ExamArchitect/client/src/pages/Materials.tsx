import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { type Course, type Material } from "@shared/schema";
import { FileText, Download, Trash2 } from "lucide-react";

export default function Materials() {
  const [selectedCourseId, setSelectedCourseId] = useState<string>("");

  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: materials } = useQuery<Material[]>({
    queryKey: ["/api/materials/course", selectedCourseId],
    enabled: !!selectedCourseId,
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900" data-testid="page-title">Materials</h1>

      <Card>
        <CardContent className="p-6">
          <div className="mb-6">
            <label className="block text-sm font-medium mb-2">Select Course</label>
            <Select value={selectedCourseId} onValueChange={setSelectedCourseId}>
              <SelectTrigger data-testid="select-course">
                <SelectValue placeholder="Choose a course" />
              </SelectTrigger>
              <SelectContent>
                {courses?.map((course) => (
                  <SelectItem key={course.id} value={course.id}>
                    {course.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedCourseId && (
            <div className="space-y-4">
              {materials && materials.length > 0 ? (
                materials.map((material) => (
                  <Card key={material.id}>
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <FileText className="text-blue-600" size={24} />
                        <div>
                          <h3 className="font-semibold" data-testid={`text-material-title-${material.id}`}>
                            {material.title}
                          </h3>
                          <p className="text-sm text-gray-600">Type: {material.type}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          <Download size={16} />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-destructive">
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-12 text-gray-500">
                  <FileText className="mx-auto mb-4" size={48} />
                  <p>No materials uploaded for this course yet.</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
