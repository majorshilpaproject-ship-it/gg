import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { type Course, type CourseOutcome, type CoPoMapping } from "@shared/schema";
import { Plus, Save } from "lucide-react";

export default function CourseOutcomes() {
  const { toast } = useToast();
  const [courseName, setCourseName] = useState("");
  const [courseDescription, setCourseDescription] = useState("");
  const [outcomes, setOutcomes] = useState<CourseOutcome[]>([
    { id: "CO1", description: "" },
    { id: "CO2", description: "" },
    { id: "CO3", description: "" },
  ]);
  const [coPoMapping, setCoPoMapping] = useState<Record<string, Record<string, number>>>({});

  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const createCourseMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/courses", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      toast({
        title: "Course Created",
        description: "Course has been created successfully.",
      });
      setCourseName("");
      setCourseDescription("");
      setOutcomes([
        { id: "CO1", description: "" },
        { id: "CO2", description: "" },
        { id: "CO3", description: "" },
      ]);
      setCoPoMapping({});
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addOutcome = () => {
    const nextNum = outcomes.length + 1;
    setOutcomes([...outcomes, { id: `CO${nextNum}`, description: "" }]);
  };

  const updateOutcome = (id: string, description: string) => {
    setOutcomes(outcomes.map(o => o.id === id ? { ...o, description } : o));
  };

  const updateCoPoMapping = (coId: string, poId: string, value: number) => {
    setCoPoMapping(prev => ({
      ...prev,
      [coId]: {
        ...(prev[coId] || {}),
        [poId]: value,
      },
    }));
  };

  const handleSaveCourse = () => {
    if (!courseName) {
      toast({
        title: "Missing Information",
        description: "Please enter a course name.",
        variant: "destructive",
      });
      return;
    }

    createCourseMutation.mutate({
      name: courseName,
      description: courseDescription,
      outcomes,
      coPoMapping,
    });
  };

  const pos = Array.from({ length: 12 }, (_, i) => `PO${i + 1}`);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900" data-testid="page-title">Define a New Course</h1>

      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">Course Name</label>
              <Input
                placeholder="e.g., DBMS"
                value={courseName}
                onChange={(e) => setCourseName(e.target.value)}
                data-testid="input-course-name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Description (optional)</label>
              <Input
                placeholder="Brief description"
                value={courseDescription}
                onChange={(e) => setCourseDescription(e.target.value)}
                data-testid="input-course-description"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Course Outcomes</h2>
            <Button onClick={addOutcome} size="sm" data-testid="button-add-outcome">
              <Plus size={16} className="mr-1" />
              Add Outcome
            </Button>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {outcomes.map((outcome) => (
              <div key={outcome.id}>
                <label className="block text-sm font-medium mb-2">{outcome.id}</label>
                <Textarea
                  placeholder={`Describe ${outcome.id}`}
                  value={outcome.description}
                  onChange={(e) => updateOutcome(outcome.id, e.target.value)}
                  className="h-24"
                  data-testid={`input-outcome-${outcome.id}`}
                />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold mb-4">CO-PO Mapping</h2>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="border border-gray-300 p-2 bg-gray-50">Outcomes</th>
                  {pos.map(po => (
                    <th key={po} className="border border-gray-300 p-2 bg-gray-50">{po}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {outcomes.map(co => (
                  <tr key={co.id}>
                    <td className="border border-gray-300 p-2 font-medium">{co.id}</td>
                    {pos.map(po => (
                      <td key={po} className="border border-gray-300 p-1">
                        <select
                          className="w-full border-0 text-center focus:ring-1 focus:ring-blue-500"
                          value={coPoMapping[co.id]?.[po] || 0}
                          onChange={(e) => updateCoPoMapping(co.id, po, parseInt(e.target.value))}
                          data-testid={`mapping-${co.id}-${po}`}
                        >
                          <option value="0">-</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          onClick={handleSaveCourse}
          disabled={createCourseMutation.isPending}
          className="bg-blue-600 hover:bg-blue-700"
          data-testid="button-save-course"
        >
          <Save size={16} className="mr-2" />
          Save Course
        </Button>
      </div>
    </div>
  );
}
