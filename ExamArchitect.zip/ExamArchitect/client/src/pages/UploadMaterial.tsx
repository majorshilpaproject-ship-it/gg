import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { type Course } from "@shared/schema";
import { Upload } from "lucide-react";

export default function UploadMaterial() {
  const { toast } = useToast();
  const [courseId, setCourseId] = useState("");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [type, setType] = useState("pdf");

  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/materials", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/materials/course"] });
      toast({
        title: "Material Uploaded",
        description: "Study material has been uploaded successfully.",
      });
      setTitle("");
      setContent("");
      setCourseId("");
    },
    onError: (error: Error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleUpload = () => {
    if (!courseId || !title || !content) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate({
      courseId,
      title,
      content,
      type,
    });
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900" data-testid="page-title">Upload Study Material</h1>

      <Card>
        <CardContent className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">Select Course</label>
            <Select value={courseId} onValueChange={setCourseId}>
              <SelectTrigger data-testid="select-course">
                <SelectValue placeholder="Choose a course" />
              </SelectTrigger>
              <SelectContent>
                {courses?.map((course) => (
                  <SelectItem key={course.id} value={course.id}>
                    {course.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Material Title</label>
            <Input
              placeholder="e.g., Chapter 1: Introduction to DBMS"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              data-testid="input-title"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Material Type</label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger data-testid="select-type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pdf">PDF</SelectItem>
                <SelectItem value="doc">Document</SelectItem>
                <SelectItem value="ppt">Presentation</SelectItem>
                <SelectItem value="text">Text</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Content</label>
            <Textarea
              placeholder="Paste or type the study material content here..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[200px]"
              data-testid="input-content"
            />
          </div>

          <div className="flex justify-end">
            <Button
              onClick={handleUpload}
              disabled={uploadMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
              data-testid="button-upload"
            >
              <Upload size={16} className="mr-2" />
              Upload Material
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
