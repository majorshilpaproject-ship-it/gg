import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { FileText, Settings, History, User } from "lucide-react";
import QuestionPaperForm from "@/components/QuestionPaperForm";
import QuestionPaperPreview from "@/components/QuestionPaperPreview";
import HistoryDialog from "@/components/HistoryDialog";
import { type SectionConfig, type GeneratedQuestion, type QuestionPaper } from "@shared/schema";

interface QuestionPaperData {
  collegeName: string;
  subjectName: string;
  subjectCode: string;
  level: string;
  semester: string;
  academicYear: string;
  totalMarks: number;
  duration: string;
  sections: SectionConfig[];
  syllabus: string;
  questions?: {
    sectionId: string;
    questions: GeneratedQuestion[];
  }[];
}

export default function Home() {
  const [paperData, setPaperData] = useState<QuestionPaperData>({
    collegeName: "",
    subjectName: "",
    subjectCode: "",
    level: "",
    semester: "",
    academicYear: "",
    totalMarks: 0,
    duration: "",
    sections: [],
    syllabus: "",
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  const handleDataUpdate = (data: Partial<QuestionPaperData>) => {
    setPaperData(prev => ({ ...prev, ...data }));
  };

  const handleGenerationStart = () => {
    setIsGenerating(true);
  };

  const handleGenerationComplete = (questions: { sectionId: string; questions: GeneratedQuestion[]; }[]) => {
    setPaperData(prev => ({ ...prev, questions }));
    setIsGenerating(false);
  };

  const handleGenerationError = () => {
    setIsGenerating(false);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <FileText className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">AI Question Paper Generator</h1>
                <p className="text-xs text-muted-foreground">Powered by Google Gemini AI</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                onClick={() => setIsHistoryOpen(true)}
                data-testid="button-history"
              >
                <History size={16} className="mr-2 inline" />
                History
              </button>
              <button 
                className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                data-testid="button-settings"
              >
                <Settings size={16} className="mr-2 inline" />
                Settings
              </button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-accent to-primary flex items-center justify-center cursor-pointer">
                <User className="text-white" size={16} />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Configuration Panel */}
          <div className="space-y-6">
            <QuestionPaperForm
              data={paperData}
              onDataUpdate={handleDataUpdate}
              onGenerationStart={handleGenerationStart}
              onGenerationComplete={handleGenerationComplete}
              onGenerationError={handleGenerationError}
              isGenerating={isGenerating}
            />
          </div>

          {/* Preview Panel */}
          <div className="lg:sticky lg:top-24 lg:self-start">
            <QuestionPaperPreview
              data={paperData}
              isGenerating={isGenerating}
            />
          </div>
        </div>
      </main>

      {/* History Dialog */}
      <HistoryDialog 
        isOpen={isHistoryOpen} 
        onClose={() => setIsHistoryOpen(false)}
        onLoadPaper={(paper: QuestionPaper) => {
          setPaperData({
            collegeName: paper.collegeName,
            subjectName: paper.subjectName,
            subjectCode: paper.subjectCode || "",
            level: paper.level,
            semester: paper.semester,
            academicYear: paper.academicYear || "",
            totalMarks: paper.totalMarks,
            duration: paper.duration,
            sections: paper.sections as SectionConfig[],
            syllabus: paper.syllabus || "",
            questions: paper.questions as { sectionId: string; questions: GeneratedQuestion[] }[] | undefined,
          });
          setIsHistoryOpen(false);
        }}
      />

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-semibold text-foreground mb-3">About</h3>
              <p className="text-sm text-muted-foreground">
                AI-powered question paper generation for educational institutions.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-3">Features</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Automated generation</li>
                <li>• Customizable sections</li>
                <li>• Difficulty balancing</li>
                <li>• Export to PDF</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-3">Resources</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Documentation</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">API Reference</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Support</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-3">Contact</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• support@qpgen.edu</li>
                <li>• +1 (555) 123-4567</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 AI Question Paper Generator. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
