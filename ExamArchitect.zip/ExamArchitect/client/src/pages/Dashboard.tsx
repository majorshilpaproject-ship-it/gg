import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, Settings, Wand2, Database, BookOpen, Eye } from "lucide-react";

export default function Dashboard() {
  const quickLinks = [
    { icon: Upload, label: "UPLOAD STUDY MATERIAL", path: "/upload", color: "bg-blue-600", testId: "quicklink-upload" },
    { icon: Settings, label: "MANAGE COURSE OUTCOMES", path: "/outcomes", color: "bg-blue-600", testId: "quicklink-outcomes" },
    { icon: Wand2, label: "GENERATE QUESTIONS", path: "/generate", color: "bg-blue-600", testId: "quicklink-generate" },
    { icon: Database, label: "QUESTION BANK", path: "/question-bank", color: "bg-blue-600", testId: "quicklink-bank" },
  ];

  const secondaryLinks = [
    { icon: BookOpen, label: "CREATE COURSE", path: "/outcomes?action=create", testId: "link-create-course" },
    { icon: Eye, label: "VIEW COURSES", path: "/outcomes?action=view", testId: "link-view-courses" },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-welcome">Welcome, Siri P</h1>
        <p className="text-gray-600" data-testid="text-department">Department: Computer Science</p>
      </div>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-6">Quick Links</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {quickLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link key={link.path} href={link.path}>
                  <Button
                    className={`${link.color} text-white h-auto py-4 w-full flex items-center justify-center space-x-2 hover:opacity-90`}
                    data-testid={link.testId}
                  >
                    <Icon size={20} />
                    <span className="font-medium">{link.label}</span>
                  </Button>
                </Link>
              );
            })}
          </div>

          <div className="flex gap-4">
            {secondaryLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link key={link.path} href={link.path}>
                  <Button
                    variant="outline"
                    className="flex items-center space-x-2"
                    data-testid={link.testId}
                  >
                    <Icon size={18} />
                    <span>{link.label}</span>
                  </Button>
                </Link>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
