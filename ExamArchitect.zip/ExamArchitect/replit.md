# Question Paper Generator - Comprehensive Academic Management System

## Overview

A comprehensive AI-powered educational platform that helps educators manage courses, upload study materials, define learning outcomes with CO-PO mapping, and generate customized question papers. The application uses Google's Gemini AI for intelligent question generation and provides a complete academic workflow from course setup to question bank management. Built with modern React frontend and Express.js backend, featuring sidebar navigation and multiple integrated modules.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React with TypeScript for type-safe component development
- Vite as the build tool and development server
- Wouter for client-side routing with sidebar navigation
- TanStack Query (React Query) for server state management and caching
- Shadcn UI components built on Radix UI primitives for accessible UI
- Tailwind CSS with blue theme matching educational platform design

**Application Structure:**
The application features a comprehensive layout with:
- **Layout Component**: Sidebar navigation with blue header and organized menu
- **Dashboard**: Welcome screen with quick links to all features
- **Course Management**: Create courses with outcomes and CO-PO mapping
- **Materials Management**: Upload and view course study materials
- **Question Generation**: AI-powered question generation linked to course outcomes
- **Question Bank**: Repository of all generated questions organized by course

**Page Components:**
- Dashboard (`/`): User welcome and quick action links
- Course Outcomes (`/outcomes`): Course creation, outcomes definition, and CO-PO mapping matrix
- Materials (`/materials`): View uploaded materials by course
- Upload Material (`/upload`): Upload study materials for courses
- Generate Questions (`/generate`): Select course and outcomes to generate questions
- Question Bank (`/question-bank`): Browse all questions organized by course and outcome

**State Management:**
- Local component state for forms and UI
- React Query for server state with automatic caching and invalidation
- Course and outcome selection drives content across modules

### Backend Architecture

**Technology Stack:**
- Express.js for HTTP server and REST API
- TypeScript for type safety across the stack
- Drizzle ORM for database operations with PostgreSQL
- Neon Database (@neondatabase/serverless) as the PostgreSQL provider
- Google Gemini AI (@google/genai) for question generation
- Zod for runtime schema validation

**Design Pattern:**
The backend uses a layered architecture:
- **Routes layer** (`server/routes.ts`): Defines API endpoints and request handling
- **Storage layer** (`server/storage.ts`): Abstracts data persistence with an interface-based approach, currently implementing in-memory storage with plans for database integration
- **Service layer** (`server/services/gemini.ts`): Handles external AI service integration

**API Structure:**
- **Course APIs**: CRUD operations for courses (`/api/courses`)
- **Material APIs**: Upload and manage study materials (`/api/materials`)
- **Question Bank APIs**: Store and retrieve generated questions (`/api/question-bank`)
- **Question Paper APIs**: Legacy question paper management (`/api/question-papers`)
- **AI Generation**: Generate questions using Gemini AI (`/api/generate-questions`)

**Rationale:**
The modular API design separates concerns for courses, materials, and questions, allowing independent management of each educational component while maintaining relationships between them.

### Data Storage

**Database:**
- PostgreSQL via Neon serverless driver for production
- Drizzle ORM provides type-safe database queries and schema management
- In-memory storage for development with full CRUD support
- Schema defined in `shared/schema.ts` using Drizzle's declarative API

**Schema Design:**
- **Users table**: Authentication with department field (id, username, password, department)
- **Courses table**: Course management with outcomes and CO-PO mapping (id, name, description, outcomes JSONB, coPoMapping JSONB)
- **Materials table**: Study materials linked to courses (id, courseId, title, content, type)
- **Question Bank table**: Generated questions linked to courses and outcomes (id, courseId, outcomeId, question, marks, difficulty, type)
- **Question Papers table**: Complete paper configurations (legacy support)

**Trade-offs:**
Using JSONB for course outcomes and CO-PO mappings provides flexibility for varying outcome structures while maintaining relational integrity through courseId foreign keys. Materials and questions are stored relationally for efficient querying by course.

### Authentication and Authorization

**Current Implementation:**
The schema includes a users table with username/password fields, but authentication middleware is not yet implemented in the routes. The application appears to be in development phase with authentication infrastructure prepared but not enforced.

**Planned Approach:**
Based on the dependencies (connect-pg-simple for session management, express-session setup), the intended authentication mechanism is session-based authentication with PostgreSQL session storage.

### External Dependencies

**AI Service Integration:**
- **Google Gemini AI** via @google/genai package
- Requires `GEMINI_API_KEY` environment variable
- Handles question generation based on subject, level, difficulty distribution, and syllabus
- Service layer (`server/services/gemini.ts`) encapsulates all AI interaction logic
- Structured prompt engineering to ensure consistent JSON response format

**Database Service:**
- **Neon Database** (@neondatabase/serverless) for serverless PostgreSQL
- Requires `DATABASE_URL` environment variable
- Connection pooling and serverless-optimized driver for efficient resource usage

**UI Component Libraries:**
- **Radix UI**: Unstyled, accessible component primitives
- **Shadcn UI**: Pre-styled components built on Radix, configured via `components.json`
- Extensive component library including forms, dialogs, dropdowns, sliders, and more

**Development Tools:**
- **Replit-specific plugins** for development environment integration (cartographer, dev banner, runtime error overlay)
- **Drizzle Kit** for database migrations and schema management
- **ESBuild** for production server bundling

**Validation:**
- **Zod** for runtime type validation on both client and server
- **drizzle-zod** for automatic Zod schema generation from Drizzle database schemas
- **@hookform/resolvers** for integrating Zod validation with React Hook Form